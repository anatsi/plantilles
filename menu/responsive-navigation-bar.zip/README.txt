A Pen created at CodePen.io. You can find this one at https://codepen.io/hanlinC/pen/dJwil.

 Responsive Navigation Bar by Grafikart.fr 
[https://www.youtube.com/watch?v=_X2N_yw9Boo](https://www.youtube.com/watch?v=_X2N_yw9Boo)

UI Color Palette from [Google Material Design](http://www.google.com/design/spec/style/color.html)